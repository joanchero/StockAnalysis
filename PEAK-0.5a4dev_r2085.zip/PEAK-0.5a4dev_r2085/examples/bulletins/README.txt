PEAK "Bulletins" Example

 "Bulletins" is a simple web-based announcements application written with
 PEAK and SQLite.  (Or at least, it will be, once it's finished.)
 The idea is to serve as a simple illustration of techniques such as 
 "executable configuration" and object-relational mapping with 'peak.storage'
 data managers.

 It is also intended as a "shakedown cruise" to test the completedness of
 PEAK's frameworks for web development.  For that reason, you should NOT
 assume that any code in this example is "the way" to do 'peak.web' apps!
 Specifically, there will be many temporary/stopgap measures taken here to
 account for missing features in 'peak.web' or other parts of PEAK.  Once
 the basic "Bulletins" app is up and running, we'll begin shoring up PEAK
 and cleaning up "Bulletins".  So until this disclaimer is no longer in the
 README, take everything you see with a grain of salt: chances are good that
 there are better ways to do things, or there will be in the near future.
 
