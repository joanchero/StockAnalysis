"""Bulletin board example"""
