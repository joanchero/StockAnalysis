"""Convenience module for use with XMI 1.1"""

from Data_Types import *
from Core import *
from Common_Behavior import *
from Use_Cases import *
from State_Machines import *
from Collaborations import *
from Activity_Graphs import *
from Model_Management import *

