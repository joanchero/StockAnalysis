"""Event-driven programming and co-operative multitasking support"""
