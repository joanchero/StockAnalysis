"""PEAK, the Python Enterprise Application Kit"""
