"""Runtime environment tools for logging, locking, process control, etc.
"""
