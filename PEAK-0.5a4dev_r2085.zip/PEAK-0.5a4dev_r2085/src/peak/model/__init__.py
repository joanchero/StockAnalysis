"""A framework for creating persistent, application domain objects"""
