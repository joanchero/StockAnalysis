"""PEAK Storage Framework - transactions, connections, persistence
"""
