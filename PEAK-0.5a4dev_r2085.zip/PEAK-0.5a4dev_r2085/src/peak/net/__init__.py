"""Network protocol implementations and other network-related features"""
