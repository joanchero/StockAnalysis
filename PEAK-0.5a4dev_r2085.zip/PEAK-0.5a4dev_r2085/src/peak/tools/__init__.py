"""Utility tools meant to be invoked via "peak" script
"""
