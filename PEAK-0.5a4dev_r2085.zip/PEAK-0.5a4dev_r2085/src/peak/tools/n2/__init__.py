"""   
PEAK N2 -- the Namespace Navigator 
"""
