"""Pre-forking process supervisor

    For the original vision document and background, see
    "this post":http://www.eby-sarna.com/pipermail/peak/2003-August/000697.html
    on the PEAK mailing list.

"""
