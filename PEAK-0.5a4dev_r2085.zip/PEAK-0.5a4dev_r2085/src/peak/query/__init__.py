"""PEAK Query Framework

    This package contains tools relating to query expressions, object filters,
    relational algebra, and generating and/or parsing SQL and other query
    languages.
"""

