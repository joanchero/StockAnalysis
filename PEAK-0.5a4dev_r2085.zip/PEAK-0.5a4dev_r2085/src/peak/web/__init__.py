"""PEAK's web application framework"""
